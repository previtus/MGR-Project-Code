This folder holds the downloaded images from StreetView and Segments dump file.
For example:
1200_downloaded/SegmentsData.dump
1200_downloaded/images/***.jpg

These are not used directly, instead via Dataset object, which provides a handler for them.