qstat -u previtus

