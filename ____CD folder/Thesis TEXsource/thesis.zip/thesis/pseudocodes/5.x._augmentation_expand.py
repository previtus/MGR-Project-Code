image_generator = ImageDataGenerator(
	rotation_range = 0,
	width_shift_range = 0.1,
	height_shift_range = 0.1,  
	horizontal_flip = True,
	vertical_flip = False
)
