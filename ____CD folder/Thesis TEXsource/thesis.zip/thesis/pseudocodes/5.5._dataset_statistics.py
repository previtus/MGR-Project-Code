Dataset.statistics()
# prints statistics over data scores
# min |-- 25th_percentile { mean } 75th_percentile --| max

Dataset.histogram()
# generates histogram of data scores